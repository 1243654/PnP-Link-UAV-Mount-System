/*---------------------------------------------------------------------*/
/* --- STC MCU Limited ------------------------------------------------*/
/* --- STC 1T Series MCU Demo Programme -------------------------------*/
/* --- ϵͳ��ʼ��ͷ�ļ� ----------------------------------------*/
/* --- ---SYS_config.h---------------------*/
/*---------------------------------------------------------------------*/

#ifndef	__SYS_config_H
#define	__SYS_config_H

#include	"config.h"
#include	"SYS_config.h"
#include	"STC32G_GPIO.h"
#include	"STC32G_NVIC.h"
#include	"STC32G_Delay.h"
#include	"STC32G_Switch.h"
#include	"STC32G_SPI.h"


extern void	GPIO_config(void);
extern void	SPI_config(void);

#endif

