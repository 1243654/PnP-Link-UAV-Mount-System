/* OSD.h            */
/*---------------------------------------------------------------------*/

#ifndef	__OSD_H
#define	__OSD_H
#include "type_def.h"



void OSD_Disply_IntNumber(u8 row,u8 columns,u8 number_len,long number);
void OSD_Disply_IntNumber_2(u8 row,u8 columns,u8 number_len,long number);
void OSD_Disply_FloatNumber(u8 line,u8 n,u8 int_n,u8 flaot_n,float y);


#endif
