
/* Base            */
/*---------------------------------------------------------------------*/

#ifndef	__Base_H
#define	__Base_H

#include "type_def.h"

bit get_byte_n(u8 byte,u8 n);//����ֽڵ�nbit=1��0
u8  SET_byte_n_H(u8 Byte,u8 n);//��λ�ֽڵ�nbit=1
u8  SET_byte_n_L(u8 Byte,u8 n);//��λ�ֽڵ�nbit=0

#endif

